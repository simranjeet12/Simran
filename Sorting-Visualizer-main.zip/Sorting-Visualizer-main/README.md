# Sorting-Visualizer

It is a web application using HTML, CSS, Javascript to visualize how various sorting algorithms work.

Algorithms Implemented:
- Bubble sort
- Selection sort
- Insertion sort
- Merge sort
- Quick sort
- Heap sort

:link: You can take a look at the live running website: https://ankitajain23.github.io/Sorting-Visualizer/
